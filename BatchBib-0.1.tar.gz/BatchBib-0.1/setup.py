from setuptools import setup

setup(
    name='BatchBib',
    version='0.1',
    packages=['batchbib','batchbib.collection','batchbib.record',
    	      'batchbib.stats','batchbib.util','batchbib.convert'],
    install_requires = [ 'PyMongo >= 2.6' ],    
)

