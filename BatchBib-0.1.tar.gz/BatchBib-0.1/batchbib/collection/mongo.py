# -*- coding: utf-8 -*-

from collections import namedtuple

from pymongo import ASCENDING

from ..record import Record
from .recordresults import LcnListRecordResults,CheckerRecordResults
from ..util.time import time_now

class MongoCollection:

	""" a record collection persisted in a mongodb collection """
	
	def __init__(self,client,dbname,colname):
	
		""" initializes a record collection persisted in mongodb
		`client`, mongo database `dbname`, mongo collection `colname`
		"""
		
		self.client = client
		self.dbname = dbname
		self.colname = colname
		
		# the mongo db and collection objects 
		self.db = self.client[dbname]
		self.col = self.db[colname]
		self.scol = self.db[colname+'_stats']
		
		# ensure record collection's indices
		self.col.ensure_index('lcn')	# NOTE: this is NOT unique!
		self.col.ensure_index('check_results.name')
		self.scol.ensure_index('name',unique=True)
				
	
	def records(self,**kwargs):
	
		""" returns an iterator over collection records.
		Without arguments all records are returned.
		TBD
		Records are sorted by _id (or optionally, lcn
		if `lcn_sort` is true) making the iterator safe 
		for updates while loping.
		"""
		
		# sort by lcn is requested
		lcn_sort = False
		# paging defaults to None
		page_start = None
		page_size = None
		
		if kwargs:
		
			# all cases, check if lcn sort is requested
			if 'lcn_sort' in kwargs:
				lcn_sort = kwargs['lcn_sort']
			
			# check if paging is requested
			page_start = kwargs.get('page_start',None)
			page_size = kwargs.get('page_size',None)
			
			# range of lcns
			if 'lcn_range' in kwargs:
				rspec = kwargs['lcn_range']
				try:
					if isinstance(rspec,str) or len(rspec)<2:
						raise ValueError('invalid lcn range in record iterator construction')
				except TypeError:
					raise ValueError('invalid lcn range in record iterator construction')
				startlcn = rspec[0]
				stoplcn = rspec[1]	
				return self._lcn_range_records(startlcn,stoplcn,lcn_sort)
				
			elif 'lcn_list' in kwargs:
				lcns = kwargs['lcn_list']
				try:
					if isinstance(lcns,str) or len(lcns)<1:
						raise ValueError('invalid lcn list in record iterator construction')
				except TypeError:
					raise ValueError('invalid lcn list in record iterator construction')
					
				return LcnListRecordResults(self,lcns,page_start,page_size)


			elif 'name' in kwargs and 'result' in kwargs:
					
				return CheckerRecordResults(self,str(kwargs['name']),str(kwargs['result']),
							    page_start,page_size)
				
		# all other cases, iterate over all records
		return self._all_records(lcn_sort)
		
		
	def _all_records(self,lcn_sort):
	
		""" iterates over all records in collection, sorted by _id
		(or lcn, if `lcn_sort` is true).
		"""
		
		if lcn_sort: skey = 'lcn'
		else: skey = '_id'
		
		for rec in self.col.find().sort(skey,ASCENDING):
			yield Record(dataobj=rec,collection=self)
			

	def _lcn_range_records(self,startlcn,stoplcn,lcn_sort):
	
		""" iterates over all records between (inclusive) `startlcn`
		and `stoplcn` in collection, sorted by _id
		(or lcn, if `lcn_sort` is true).
		"""
		
		if lcn_sort: skey = 'lcn'
		else: skey = '_id'
		
		for rec in self.col.find({'lcn':{'$gte':startlcn,
						 '$lte':stoplcn}}).sort(skey,ASCENDING):
			yield Record(dataobj=rec,collection=self)
			
					
					
	def store(self,record):
	
		""" persists a `record` into mongodb if either its parent collection is
		not this collection or if it is changed.
		"""
		
		if record.collection is self:	# if record belongs to this collection
		
			if record.changed:	# record is marked as changed
				dob = record.dataobj	# record's raw data
				self.col.update({'_id':dob['_id']},dob)
				record.changed = False
				
		else:	# record is either 'fresh' or belongs to another collection
			dob = record.dataobj
			if '_id' in dob: del dob['_id']
			newid = self.col.insert(dob)
			# update the in-memory id of record
			dob['_id'] = newid
			# mark as unchanged
			record.changed = False
			# re-parent record
			record.collection = self
	
	
	def detach(self,record):
	
		""" detaches `record` from collection. Record object
		continues without parent collection and without _id (if previously existed)
		"""
		
		# remove record from collection
		self.col.remove({'_id':record.dataobj['_id']},multi=False)
		# mark record as parent-less
		record.collection = None
		# remove _id if exists
		dob = record.dataobj
		if '_id' in dob: del dob['_id']
		

	def update_check_stats(self,checker_counter):
	
		""" utility method that updates collections's check results
		with statistics from global counts of `checker_counter`.
		"""
		
		# for each checker
		for checker_name,checker_info in checker_counter.results.items():
			 
			# the output object for this checker
			ob = {'name':checker_name,
			       'description':checker_info['description'],
			       'check_ts':time_now()}
			
			nstatl = []
			# for each type of result
			for result_name,result_info in checker_info['results'].items():
				rob = {'type':result_name,
				       'descr':{'errorlevel':result_info['severity'],
				       		'descr':result_info['description']},
				       'count':result_info['global']}
				nstatl.append(rob)
				
			# sort stats by severity (ascending: pass(0) -> fail(3))
			nstatl.sort(key=lambda rob: rob['descr']['errorlevel'])
			
			# add stats tou output object
			ob['stats'] = nstatl
			
			# finally, store output object into stats collection (replace any previous)
			self.scol.update({'name':checker_name},ob,upsert=True)
	
	
	def check_stats(self,checker=None):
	
		""" returns checker-results stored in collection for `checker`.
		Returns a tuple (checker-name,checker-description,checker-results)
		for selected chcecker, where checker-results is a list of named tuples
		of (name,severity,description,count) for each test in checker.
		If no `checker` name exists in collection's stats, returns None.
		
		If `checker` is None, a list of (checker-name,checker-description,checker-results)
		tuples is returned, for all checkers stored.
		"""
		

		
		if checker:
			statrecs = self.scol.find({'name':checker})
		else:
			statrecs = self.scol.find()
			
		retl = []
		Results = namedtuple('Results',['name','severity','description','count'])

		for chk in statrecs:
			results = [Results(name=r['type'],
				           severity=r['descr']['errorlevel'],
				           description=r['descr']['descr'],
				           count=r['count']) for r in chk['stats']]
			retl.append((chk['name'],chk['description'],results))
			
		if checker:
			if retl: return retl[0]	# return 1st item (should be the only one)
			
			return None	# checker name not found
		
		# no checker specified, return list of checkers found
		return retl
