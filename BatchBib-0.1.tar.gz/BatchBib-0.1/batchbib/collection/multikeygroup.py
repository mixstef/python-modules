# -*- coding: utf-8 -*-

from pymongo import ASCENDING

class MultiKeyGroup:

	""" a class for collections of documents with one or more keys,
	persisted in mongo db and having the capability of beeing held
	in memory
	"""
	
	def __init__(self,client,dbname,colname,keylist,in_memory=False):
	
		""" inits a multikeygroup object persisted via `client` mongo client,
		in database `dbname` and collection `colname`.
		`keylist` is a non-empty list of key names that may exist in
		stored items. If `in_memory` is true, the groups will be loaded
		or created in-memory.
		"""
		
		self.client = client
		self.dbname = dbname
		self.colname = colname
		self.db = client[self.dbname]
		self.col = self.db[self.colname]
		
		if len(keylist)<1:
			raise ValueError('multikeygroup must have at least one key defined')
		self.keyset = set(keylist)
			
		self.in_memory = False
		
		# if in_memory flag is true, load groups from db
		if in_memory:
			self.load()
			
			
	def load(self):
	
		""" load groups from database into memory, for items that
		have at least one key from the ones specified in keyset
		"""
		
		if self.in_memory: return	# already in memory
		
		# prepare the in-memory structs
		self.dicts = {}
		for key in self.keyset:
			self.dicts[key] = {}
		
		# load all records
		for item in self.col.find():
			# keep only items that have at least one key from the ones specified
			for key in self.keyset:
				if key in item:	# key exists in item
					self.dicts[key].setdefault(item[key],[]).append(item)
		
		# mark state as 'in-memory'
		self.in_memory = True		
		# init tracking changelog
		self.changelog = []
	
	
	def _append_to_db(self,item):
	
		""" appends an item (object) to mongo db, called when groups
		are held in db
		"""
		
		# insert item object into db
		self.col.insert(item)
		# ensure indices, for all indices in keyset
		idx_list = [(idx,ASCENDING) for idx in self.keyset]
		self.col.ensure_index(idx_list)
		
		
	def _append_to_memory(self,item):
	
		""" appends an item (object) to in-memory dicts,
		called when groups are held in-memory
		"""
		
		# append item to lists of all keys that it contains
		for key in self.keyset:
			if key in item:	# key exists in item
				self.dicts[key].setdefault(item[key],[]).append(item)
		
		# append item to changelog - this must be written back to db on store
		self.changelog.append(item)
		
		
	def append(self,item):
	
		""" appends an item (object) to groups that item's keys specify """
		
		if self.in_memory:	# structures are in memory
			self._append_to_memory(item)
		else:	# data is on db
			self._append_to_db(item)
	
	
	def _group_in_db(self,key,value):
	
		""" returns a cursor for a group in db that, for key `key`
		has value `value`
		"""
		
		return self.col.find({key:value})


	def _group_in_memory(self,key,value):
	
		""" returns a list of objects in a in-memory group that, for key `key`
		has value `value`
		"""
		
		# if key does not exist, simply return empty list
		if key not in self.dicts:
			return []
		
		# return group for value, or empty list if value not in	
		return self.dicts[key].get(value,[])
						
						
	def group(self,key,value):
	
		""" returns a sequence of group members for key `key`
		and value `value`
		"""
		
		if self.in_memory:	# structures are in memory
			self._group_in_memory(key,value)
		else:	# data is on db
			self._group_in_db(key,value)
	
	
	def store(self):
	
		""" stores all group info form memory to db """
		
		# do nothing if already in db
		if not self.in_memory: return
		
		# store in db all objects marked as changed in changelog
		for ob in self.changelog:
			self.col.insert(ob)
		
		# ensure indices, for all indices in keyset
		idx_list = [(idx,ASCENDING) for idx in self.keyset]
		self.col.ensure_index(idx_list)

		# mark state as 'in-db'
		self.in_memory = False
		

