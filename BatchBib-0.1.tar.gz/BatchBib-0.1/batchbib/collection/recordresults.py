
from pymongo import ASCENDING

from ..record import Record


class RecordResults:

	""" a base class for sets of records, returned as a response to
	a collection scan/search request. Results support simple paging,
	from page_start page (0-based) with up to page_size records per page.
	""" 

	def __init__(self,cursor,page_start,page_size):
	
		if page_start is not None and page_size is not None:
			# from "page_start" page with up to "page_size" results
			self.cursor = cursor.skip(page_start*page_size).limit(page_size)
		else:	# no pagination
			self.cursor = cursor
		
		self.collection = None	# should be overridden by subclasses
	
	def __iter__(self):
	
		""" iterates over records in result set """
		
		for rec in self.cursor:
			yield Record(dataobj=rec,collection=self.collection)
		

	def __next__(self):
	
		""" next record in result set """
		
		return Record(dataobj=next(self.cursor),collection=self.collection)
		


	def __len__(self):
	
		""" number of records in result set (page, if pagination requested)  """
	
		return self.cursor.count(with_limit_and_skip=True)
	

	def total(self):
	
		""" number of total records in result set (not in page, if pagination requested)  """
	
		return self.cursor.count()
	


class TotalRecordResults(RecordResults):

	""" a result set containing all records in a collection """
	
	def __init__(self,collection,page_start=None,page_size=None):
		
		col = collection.col	# the mongo collection of this record collection
		cursor = col.find().sort('lcn',ASCENDING)
	
		super().__init__(cursor,page_start,page_size)
		
		# will be used by base class to yield records connected to this collection
		self.collection = collection



class LcnListRecordResults(RecordResults):

	""" a result set containing records with lcns from a list """
	
	def __init__(self,collection,lcn_list,page_start=None,page_size=None):
		
		col = collection.col	# the mongo collection of this record collection		
		cursor = col.find({'lcn':{'$in':lcn_list}}).sort('lcn',ASCENDING)
	
		super().__init__(cursor,page_start,page_size)
		
		# will be used by base class to yield records connected to this collection
		self.collection = collection



class CheckerRecordResults(RecordResults):

	""" a result set containing records with specific checker_result name/result """
	
	def __init__(self,collection,name,result,page_start=None,page_size=None):
		
		col = collection.col	# the mongo collection of this record collection		
		cursor = col.find({'check_results.name':name,
				   'check_results.result':result}).sort('lcn',ASCENDING)
	
		super().__init__(cursor,page_start,page_size)
		
		# will be used by base class to yield records connected to this collection
		self.collection = collection
								
