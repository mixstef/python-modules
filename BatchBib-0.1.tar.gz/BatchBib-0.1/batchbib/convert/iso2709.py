# -*- coding: utf-8 -*-

""" Module handling conversions to and from iso2709 format """


from batchbib.record import Leader,DataField,ControlField,Subfield,Record


SUBFIELD_TERMINATOR = b'\x1f'
FIELD_TERMINATOR = b'\x1e'
RECORD_TERMINATOR = b'\x1d'

def encode_record(record,encoding='utf-8'):

	""" returns a bytestring representation of `record` data,
	according to iso2709 specification. An optional encoding
	argument can be given, defaulting to utf-8.
	"""
	
	# encode fields
	infol = []	# list to keep tag and length of each field
	fieldl = []	# list to keep bytestrings of fields
	for field in record.fields():
		if isinstance(field,ControlField):
			bstr = encode_control_field(field,encoding)
		else:
			bstr = encode_data_field(field,encoding)
	
		fieldl.append(bstr)
		infol.append((field.tag,len(bstr)))
	
	fieldl.append(RECORD_TERMINATOR)	# last byte of record, after fields
	fieldbstr = b''.join(fieldl)	# total bytestring of encoded fields + record terminator
	
	# encode directory
	dirbstr = encode_directory(infol)	# bytestring of encoded directory 
	
	# encode leader
	base = 24+len(dirbstr)
	total = base+len(fieldbstr)
	ldrbstr = encode_leader(record.leader,total,base)	# bytestring of encoded leader
	
	return b''.join((ldrbstr,dirbstr,fieldbstr))		
	
	
def encode_data_field(dfield,encoding):

	""" returns a bytestring representation of data field `dfield` data,
	according to iso2709 specification. Data will be converted with
	`encoding` encoder.
	"""
	
	d = dfield.dataobj
	parts = [d['ind1'].encode('ascii'),d['ind2'].encode('ascii')]
	
	for sf in d['subfields']:
		parts += [SUBFIELD_TERMINATOR,sf['code'].encode('ascii'),
			  sf['data'].encode(encoding)]
	
	parts.append(FIELD_TERMINATOR)
			  
	return b''.join(parts)
	

def encode_control_field(cfield,encoding):

	""" returns a bytestring representation of control field `cfield` data,
	according to iso2709 specification. Data will be converted with
	`encoding` encoder.
	"""
	
	return b''.join([cfield.dataobj['data'].encode(encoding),FIELD_TERMINATOR])


def encode_leader(leader,total,base):

	""" returns a bytestring representation of leader `leader` data,
	according to iso2709 specification. `total` is the total length
	of bytestring of record and `base` is the offset of 1st byte of
	data (after leader and after dirctory).
	"""
	
	ld = leader.dataobj['data'].encode('ascii')
	
	parts = ['{:05d}'.format(total).encode('ascii'),
		 ld[5:12],
		 '{:05d}'.format(base).encode('ascii'),
		 ld[17:]]
	
	return b''.join(parts)


def encode_directory(field_list):

	""" returns a bytestring representation of a record's directory,
	according to iso2709 specification. `field_list` is a list of tuples
	(tag,field bytelen), for all fields in record.
	"""
	
	parts = []
	pos = 0
	for tag,blen in field_list:
		parts.append('{:03d}{:04d}{:05d}'.format(tag,blen,pos).encode('ascii'))
		pos += blen
		
	# directory also has a field terminator at end
	parts.append(FIELD_TERMINATOR)
	
	return b''.join(parts)
	

class Iso2709Writer:

	""" writes records in a file-like object in iso2709 format """
	
	def __init__(self,fp,encoding='utf-8'):
	
		self.fp = fp
		self.encoding = encoding
		
		
	def write(self,record):
	
		""" appends `record` to output file-like object in iso2709 format """
		
		# create a bytestring of record data in iso2709 format
		bstr = encode_record(record,self.encoding)
		# write to file object
		self.fp.write(bstr)


		
def decode_leader(leader_slab):

	""" returns a triple (leader,total,base) from a bytestring representation
	of leader `leader_slab` data, according to iso2709 specification. 
	leader is a Leader object, total is the total length
	of bytestring of record and base is the offset of 1st byte of
	data (after leader and after directory).
	"""
	
	return Leader(data=leader_slab.decode('ascii')), \
	       int(leader_slab[:5].decode('ascii')), \
	       int(leader_slab[12:17].decode('ascii'))


def decode_directory(directory_slab):

	""" returns a list of tuples (tag,field bytelen,field position),
	for all fields in record from `directory_slab`, a bytestring
	representation of a record's directory, according to iso2709 specification.
	`directory_slab` is expected to have FIELD_TERMINATOR as last byte.
	"""
	# check if last byte is FIELD_TERMINATOR
	if directory_slab[-1:]!=FIELD_TERMINATOR:	# NOTE: use [-1:] to get bytes instead of int!
		raise ValueError("field terminator byte missing in directory data")

	# check size of directory slab
	dirlen = len(directory_slab) - 1	# without FIELD_TERMINATOR
	if (dirlen%12)!=0:
		raise ValueError("incorrect directory data length")	
	
	# decompose directory info
	offset = 0		# used for length/position validation
	pos = 0
	fields = []
	while pos<dirlen:
		tag = int(directory_slab[pos:pos+3])
		field_len = int(directory_slab[pos+3:pos+7])
		field_pos = int(directory_slab[pos+7:pos+12])		
		# check length/position validity
		if offset!=field_pos:
			raise ValueError("wrong field offset in directory data")

		fields.append((tag,field_len,field_pos))
		pos += 12
		offset += field_len
		
	return fields
	
	
def decode_control_field(tag,cfield_slab,encoding):

	""" returns a control field with `tag` number, from a bytestring `cfield_slab`
	according to iso2709 specification. Data will be converted with
	`encoding` decoder.
	`cfield_slab` is expected to have FIELD_TERMINATOR as last byte.
	"""
	
	# check if last byte is FIELD_TERMINATOR
	if cfield_slab[-1:]!=FIELD_TERMINATOR:	# NOTE: use [-1:] to get bytes instead of int!
		raise ValueError("field terminator byte missing in control field data")
	
	return ControlField(tag=tag,data=cfield_slab[:-1].decode(encoding))
	
	
def decode_data_field(tag,dfield_slab,encoding):

	""" returns a data field with `tag` number, from a bytestring `dfield_slab`
	according to iso2709 specification. Data will be converted with
	`encoding` decoder.
	`dfield_slab` is expected to have FIELD_TERMINATOR as last byte.
	"""

	# check if last byte is FIELD_TERMINATOR
	if dfield_slab[-1:]!=FIELD_TERMINATOR:	# NOTE: use [-1:] to get bytes instead of int!
		raise ValueError("field terminator byte missing in data field data")

	# check if slab has sufficient length (2 indicators+SUBFIELD_TERMINATOR+FIELD_TERMINATOR)
	if len(dfield_slab)<4:
		raise ValueError("data field has not minimum length")
		
	ind1 = dfield_slab[:1].decode('ascii')
	ind2 = dfield_slab[1:2].decode('ascii')
	
	subfields = []	# list of Subfield objects
	
	# if there are any subfields
	if len(dfield_slab[2:-1])>0:
		
		# split subfields per SUBFIELD_TERMINATOR
		sfl = dfield_slab[2:-1].split(SUBFIELD_TERMINATOR)
		
		# check if SUBFIELD_TERMINATOR after indicators
		if sfl[0]!=b'':
			raise ValueError("missing subfield terminator after indicators of data field")
		
		for sf in sfl[1:]:
			if sf==b'':
				raise ValueError("empty subfield in data field")
				
			subfields.append(Subfield(code=sf[:1].decode('ascii'),data=sf[1:].decode(encoding)))
	
	return DataField(tag=tag,ind1=ind1,ind2=ind2,subfields=subfields)
	

def decode_record(record_slab,encoding='utf-8'):

	""" returns a record object form a bytestring representation `record_slab`,
	according to iso2709 specification. An optional encoding
	argument can be given, defaulting to utf-8.
	`record_slab` is expected to have RECORD_TERMINATOR as last byte.
	"""

	# check if last byte is RECORD_TERMINATOR
	if record_slab[-1:]!=RECORD_TERMINATOR:	# NOTE: use [-1:] to get bytes instead of int!
		raise ValueError("record terminator byte missing in record data")
	
	# decode leader
	if (len(record_slab)-1)<24:	# no full leader?
		raise ValueError("record has incorrect leader length")
	leader,total,base = decode_leader(record_slab[:24])

	# decode directory
	if (len(record_slab)-1)<base:	# no full directory?
		raise ValueError("record has incorrect directory length")
	field_dir = decode_directory(record_slab[24:base])
	
	fields = []
	for tag,flen,fpos in field_dir:
		pos = base+fpos
		if tag<10: fields.append(decode_control_field(tag,record_slab[pos:pos+flen],encoding))
		else: fields.append(decode_data_field(tag,record_slab[pos:pos+flen],encoding))

	# assemble and return record object
	return Record(leader=leader,fields=fields)
	


class Iso2709Reader:

	""" yields records from a file-like object in iso2709 format """
	
	def __init__(self,fp,encoding='utf-8'):
	
		self.fp = fp
		self.encoding = encoding
		
	
	def next_slab_size(self):
	
		""" returns size of next record slab. Raises ValueError
		if size (5 bytes) cannot be read from file or size is invalid
		(non numeric). If at end of file, returns 0. """
		
		bstr = self.fp.read(5)
		if len(bstr)==0: return 0	# nothing to read anymore
		if len(bstr)<5:		# malformed file
			raise ValueError("malformed record size in input file")	
		
		try:
			reclen = int(bstr)
		except ValueError:
			raise ValueError("invalid record size in input file")
		
		if reclen<5:
			raise ValueError("unsufficient record size in input file")
					
		return reclen

	
	def next_slab(self):
	
		""" reads next slab from input file, if any.
		Returns None if no more slabs can be read.
		Raises ValueError if unsufficient bytes read."""
		
		reclen = self.next_slab_size()
		if not reclen: return None	# end of file reached
		
		# read rest record
		rest_size = reclen-5
		rest = self.fp.read(rest_size)
		
		if len(rest)!=(rest_size):
			raise ValueError("Unsufficient bytes to complete record")
		
		# assemble record slab	
		return b''.join(['{:05d}'.format(reclen).encode('ascii'),rest])
		
		
	def __iter__(self):
	
		""" iterates over records in input file """
		
		while True:
			slab = self.next_slab()
			if slab is None: return
			yield decode_record(slab,self.encoding)
		

	def __next__(self):
	
		""" next record in input file """
		
		slab = self.next_slab()
		if slab is None: raise StopIteration
		return decode_record(slab,self.encoding)
		


	
