# -*- coding: utf-8 -*-

from datetime import datetime,timezone,timedelta
import time

def time_now():

	""" utility function that returns datetime.now() with current zone """
	
	if time.daylight!=0:	# DST option exists
		if time.gmtime().tm_isdst==0:	# no dst
			tzsec = time.timezone
		else:
			tzsec = time.altzone		
	else:
		tzsec = time.timezone
			
	tz = timezone(-timedelta(seconds=tzsec))
	return datetime.now(tz)	
