# -*- coding: utf-8 -*-

from .attach import AttachmentManager

class Subfield(AttachmentManager):

	""" a subfield wrapper class """
	
	def __init__(self,**kwargs):
	
		""" Initializes a subfield instance in various ways,
		according to `kwargs` given, with following priority:
		
		A `dataobj` kwarg is used to fast initialize subfield
		from a database document, without checking input validity.
		Alternatively, `code` (a letter between '0'-'9' or 'a'-'z'),
		and `data` (a string) describe parts of subfield.
		In case of `dataobj`, an optional `parent` argument can
		be provided, referencing the record that contains this subfield. 
		"""
	
		# the parent field, if any
		self.parent = None
	
		# check if raw data present
		if 'dataobj' in kwargs:
			
			self.dataobj = kwargs['dataobj']	# NOTE: validity of data is NOT tested!

			if 'parent' in kwargs:
				self.parent = kwargs['parent']

		elif 'code' in kwargs and 'data' in kwargs:
			self.dataobj = {}
			
			# following will be checked for validity in property setters		
			self.code = kwargs['code']			
			self.data = kwargs['data']			
					 
		else:
			raise ValueError("missing arguments in control field definition")


	@property
	def changed(self):
		# no read access to this attribute
		raise AttributeError('cannot read "changed" subfield attribute')

	@changed.setter
	def changed(self,value):
		if value and self.parent is not None:	# if set to True and there is a parent
			# cascade - set parent's changed attribute
			self.parent.changed = True
		# for any other case, do nothing


	@property
	def code(self):
		return self.dataobj['code']

	@code.setter
	def code(self,value):

		value = str(value)
		if len(value)!=1:
			raise ValueError("invalid code value for subfield")		
		
		if not ((value>='0' and value<='9') or (value>='a' and value<='z')):
			raise ValueError("invalid code value for subfield")		
			
		# only if case of code change - NOTE: old value will be missing in construction case
		if 'code' not in self.dataobj or value != self.dataobj['code']:

			self.dataobj['code'] = value
			self.changed = True
			
			# if field is parented, re-arrange tag
			if self.parent is not None:
				parent = self.parent	# keep after detach
				self.parent.detach_subfield(self)
				parent.add_subfields(self)


	@property
	def data(self):
		return self.dataobj['data']

	@data.setter
	def data(self,value):
		self.dataobj['data'] = str(value)
		self.changed = True



