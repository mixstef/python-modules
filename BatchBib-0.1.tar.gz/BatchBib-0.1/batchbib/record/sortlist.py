# -*- coding: utf-8 -*-

def sortlist_add(sortlist,key,sort_key,*args):

	""" adds new dicts contained in `args` to `sortlist` in an
	ordered fashion: value of `key` in each dict is compared
	against ones existing in list and greater items are inserted
	in sorted order. For equal keys, insertion order is kept.
	`sort_key` is a one-argument function, returning the compare
	value for each key. 
	"""
	
	for item in args:
	
		# if list is empty or new item must be put at end
		if len(sortlist)==0 or sort_key(sortlist[-1][key])<=sort_key(item[key]):
			sortlist.append(item)
		else:
			# find insertion position (linear search)
			for pos,olditem in enumerate(sortlist):
				if sort_key(olditem[key])>sort_key(item[key]):
					break
			# insert new element
			sortlist.insert(pos,item)


def sortlist_get(sortlist,key,*args):

	""" returns items (dicts) in `keylist`, selected by
	value of `key` in each dict. If no args are given,
	the whole `keylist` is returned.
	"""

	if len(args)==0: return sortlist[:]	# shallow copy of keylist

	# create set of keys to be returned
	rset = set(args)
	
	# return items with key in rset
	return [item for item in sortlist if item[key] in rset]


def sortlist_extract(sortlist,key,*args):

	""" returns items (dicts) and removes them from `keylist`,
	selected by value of `key` in each dict. If no args are given,
	the whole `keylist` is returned.
	"""

	if len(args)==0: 
		retl = sortlist[:]	# shallow copy of keylist
		sortlist[:] = []
		return retl
	
	# create set of keys to be returned
	rset = set(args)
	
	# extracted items with key in rset
	retl = [item for item in sortlist if item[key] in rset]

	# modify original list to items with key not in rset
	sortlist[:] = [item for item in sortlist if item[key] not in rset]
	
	return retl


def sortlist_detach(sortlist,item):

	""" detaches (removes but not modifies) an existing `item`
	from `sortlist`. Returns True if item was found and detached, False
	otherwise.
	"""
	
	for pos,existingitem in enumerate(sortlist):
		if existingitem is item:
			break
	else:	# item not found in sortlist
		return False
		
	del sortlist[pos]
	return True
