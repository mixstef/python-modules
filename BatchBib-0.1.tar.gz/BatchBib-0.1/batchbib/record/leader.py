# -*- coding: utf-8 -*-

from .attach import AttachmentManager


class Leader(AttachmentManager):

	""" A wrapper class for the leader of a marc record """
	
	# if leader constructed from parts, these are mandatory 
	needed = {'record_status','implementation_codes','encoding_level'}
	# leader parts and their position/length
	parts = {'record_status':{'length':1,'start':5},
		 'implementation_codes':{'length':4,'start':6},
		 'encoding_level':{'length':1,'start':17},
		 'octet18':{'length':1,'start':18},
		 'octet19':{'length':1,'start':19},
		 }
		
	def __init__(self,**kwargs):
	
		""" Initializes a leader instance in various ways,
		according to `kwargs` given, with following priority:
		
		A `dataobj` kwarg is used to fast initialize leader
		from a database document, without checking input validity.
		A `data` kwarg contains the full leader string.
		Alternatively, `record_status`, `implementation_codes`, `encoding_level`
		(and optionally `octet18` and `octet19`) describe parts of leader.
		In case of `dataobj`, an optional `parent` argument can
		be provided, referencing the record that contains this leader. 
 
		"""
	
		# the parent record, if any
		self.parent = None
	
		# check if raw data present
		if 'dataobj' in kwargs:
			
			self.dataobj = kwargs['dataobj']	# NOTE: validity of data is NOT tested!

			if 'parent' in kwargs:
				self.parent = kwargs['parent']
			
		elif 'data' in kwargs:	# content is given as string
			
			try:
				# check length (ascii bytes)
				bdata = kwargs['data'].encode('ascii')
				if len(bdata)!=24:
					raise ValueError("wrong length of characters in leader definition")	
					
			except UnicodeEncodeError:
				raise ValueError("non-ASCII characters in leader definition")	
		
		
			# set leader info and force fixed values
			data = kwargs['data']
			self.dataobj = {'data':''.join([data[:10],'22',data[12:20],'45',data[22:]])}
						
		else:	# leader is given as parts
			
			# check for presence of needed parts
			if not self.needed.issubset(kwargs):
				raise ValueError("missing arguments in leader definition")	

			# the bytearray to be filled
			barr = bytearray(b'00000_____2200000_  45 0')
			# fill with args given, testing length and content at same time
			try:
				for arg,value in kwargs.items():
					if arg in self.parts:
						d = self.parts[arg]
						bval = value.encode('ascii')
						if len(bval)!=d['length']:
							raise ValueError("wrong length of characters in leader definition")
						barr[d['start']:d['start']+d['length']] = bval
				
				# store rawdata as normal string
				self.dataobj = {'data':barr.decode('ascii')}
						
			except UnicodeEncodeError:
				raise ValueError("non-ASCII characters in arguments of leader definition")	
			
			
		
	
	def __getattr__(self,name):
	
		if name in self.parts:
			d = self.parts[name]
			return self.dataobj['data'][d['start']:d['start']+d['length']]
			
		elif name=='value':
			return self.dataobj['data']
			
		else:
			raise AttributeError('leader has no attribute \'{0}\''.format(name))
	
			
	def __setattr__(self,name,value):
	
		if name in self.parts:
			try:
				d = self.parts[name]		
				bval = value.encode('ascii')
				if len(bval)!=d['length']:
					raise ValueError("wrong length of characters in attribute value")
				
				oldval = self.dataobj['data']
				start = d['start']
				end = d['start']+d['length']				
				self.dataobj['data'] = oldval[:start]+value+oldval[end:]
				# signal record part change
				self.changed = True

			except UnicodeEncodeError:
				raise ValueError("non-ASCII characters in leader attribute value")	
		
		elif name=='value':
			try:
				bval = value.encode('ascii')
				if len(bval)!=24:
					raise ValueError("wrong length of characters in leader value")
				
				self.dataobj['data'] = value
				# signal record part change
				self.changed = True

			except UnicodeEncodeError:
				raise ValueError("non-ASCII characters in leader value")	
		
		else:	# allow any other attr assignment the usual way
			object.__setattr__(self,name,value)
			
			
	@property
	def changed(self):
		# no read access to this attribute
		raise AttributeError('cannot read "changed" leader attribute')

	@changed.setter
	def changed(self,value):
		if value and self.parent is not None:	# if set to True and there is a parent
			# cascade - set parent's changed attribute
			self.parent.changed = True
		# for any other case, do nothing


