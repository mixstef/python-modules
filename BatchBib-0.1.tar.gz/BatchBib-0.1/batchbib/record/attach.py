# -*- coding: utf-8 -*-

import copy

from .keylist import keylist_get,keylist_add,keylist_extract

class Attachment:

	""" an attachment object class, storing a `key`
	and a `value` for attachment instances.
	"""
	
	def __init__(self,**kwargs):
	
		""" Initializes an attachment instance in various ways,
		according to `kwargs` given, with following priority:
		
		A `dataobj` kwarg is used to fast initialize attachment
		from a database document, without checking input validity.
		Alternatively, `key` and `value` can initialize attachment.
		In case of `dataobj`, an optional `parent` argument can
		be provided, referencing the parent record-part of attachment. 
		"""
	
		# check if raw data present
		if 'dataobj' in kwargs:
			
			self.dataobj = kwargs['dataobj']	# NOTE: validity of data is NOT tested!	
			
			if 'parent' in kwargs:
				self.parent = kwargs['parent']
			else:
				self.parent = None
			
		elif 'key' in kwargs and 'value' in kwargs:
		
			self.dataobj = {'key':kwargs['key'],'value':kwargs['value']}
			self.parent = None	
		
		else:
			raise ValueError("missing arguments in attachment definition")
		

	@property
	def key(self):
		return self.dataobj['key']
		
	@key.setter
	def key(self,value):
		self.dataobj['key'] = value
		if self.parent is not None:	# reposition attachment in parent list
			self.parent.set_attachments(self)
	
		
	@property
	def value(self):
		return self.dataobj['value']
		
	@value.setter
	def value(self,value):
		self.dataobj['value'] = value
		if self.parent is not None:	# reposition attachment in list
			self.parent.set_attachments(self)
	
		
class AttachmentManager:

	""" a class to be used as mixin for record parts,
	providing attachment handling functionality.
	Operates on `dataobj` attribute of classes that inherit it.
	"""
	
	def get_attachments(self,*args):
	
		""" returns a list of attachments with keys matching `args`.
		If no `args` is provided, returns all attachments.
		If no attachments present, an empty list is returned
		"""
		
		if 'attachments' not in self.dataobj:
			return []
		
		attlist = keylist_get(self.dataobj['attachments'],'key',*args)
		
		# create and return Attachment objects (wrappers) with parent set to self
		return [Attachment(dataobj=att,parent=self) for att in attlist]	


	def set_attachments(self,*args):
	
		""" inserts a list of attachments in `args`, possibly replacing
		existing ones with same `key`. If an attachment given has already
		a different parent, a deep-copy is inserted instead.
		"""
		
		# create attachments list if it does not exist
		if 'attachments' not in self.dataobj:
			self.dataobj['attachments'] = []

		# target container to insert attachments
		target = self.dataobj['attachments']
		
		for attachment in args:
		
			# check if we try to insert an attachment belonging to another parent
			if attachment.parent is not None and attachment.parent is not self:
				# make a deep copy of attachment dataobj
				copyobj = copy.deepcopy(attachment.dataobj)
				# set this as the dataobj of attachment
				attachment.dataobj = copyobj
			
			# insert (set by key name) into target container
			keylist_add(target,'key',attachment.dataobj)
			# set container of attachment equal to target
			attachment.parent = self
		
		# signal change for this record part (self)
		self.changed = True
		 

	def extract_attachments(self,*args):
	
		""" returns a list of attachments with keys matching `args`,
		removing them at the same time from the attachment list.
		If no `args` is provided, all attachments are extracted.
		If no attachments present, an empty list is returned.
		"""

		if 'attachments' not in self.dataobj:
			return []

		# extract matching attachments
		extracted = keylist_extract(self.dataobj['attachments'],'key',*args)
		
		# if attachments left are zero, remove the attachment list
		if len(self.dataobj['attachments'])==0:
			del self.dataobj['attachments']

		# if any attachments extracted
		if len(extracted)>0:
			# signal change for this record part (self)
			self.changed = True
		
		# return list of extracted Attachments, they have no parent
		return [Attachment(dataobj=att,parent=None) for att in extracted]

