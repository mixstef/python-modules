# -*- coding: utf-8 -*-

def keylist_add(keylist,key,*args):

	""" adds new dicts contained in `args` to `keylist` in a
	set-like fashion: value of `key` in each dict is compared
	against ones existing in list and matching items replace older.
	At the same time, insertion order is kept. 
	"""

	if len(args)==0: return # no args?

	# build a version of args without duplicate keys
	d = {}
	for ix,item in enumerate(args):
		d[item[key]] = ix
	
	clean = list(d.values())
	clean.sort()		
	
	# remove old keys before addition	
	newlist = []
	for item in keylist:
		if item[key] not in d:
			newlist.append(item)
	# modify original list
	keylist[:] = newlist
	
	# add new items
	for ix in clean:
		keylist.append(args[ix])


def keylist_get(keylist,key,*args):

	""" returns items (dicts) in `keylist`, selected by
	value of `key` in each dict. If no args are given,
	the whole `keylist` is returned.
	"""
	
	if len(args)==0: return keylist[:]	# shallow copy of keylist
	
	# create set of keys to be returned
	rset = set(args)
	
	# return items with key in rset
	return [item for item in keylist if item[key] in rset]
	

def keylist_extract(keylist,key,*args):

	if len(args)==0: 
		retl = keylist[:]	# shallow copy of keylist
		keylist[:] = []
		return retl
	
	# create set of keys to be returned
	rset = set(args)
	
	# extracted items with key in rset
	retl = [item for item in keylist if item[key] in rset]

	# modify original list to items with key not in rset
	keylist[:] = [item for item in keylist if item[key] not in rset]
	
	return retl
