# -*- coding: utf-8 -*-

from datetime import datetime
import copy

from .attach import AttachmentManager
from .leader import Leader
from .field import ControlField,DataField,Field
from .keylist import keylist_add,keylist_get,keylist_extract
from .sortlist import sortlist_get,sortlist_add,sortlist_extract,sortlist_detach
from ..util.time import time_now

class Record(AttachmentManager):

	""" A wrapper class for a marc record """

	def __init__(self,**kwargs):
	
		""" Initializes a record instance in various ways,
		according to `kwargs` given, with following priority:
		
		A `dataobj` kwarg is used to fast initialize record
		from a database document, without checking input validity.
		Alternatively, `leader` (a Leader object) and `fields`
		(a list of Field objects) can initialize the record,
		
		In case of `dataobj`, an optional `collection` argument can
		be provided, referencing the collection that contains this record. 		
		"""
		
		self.collection = None
		
		# check if raw data present
		if 'dataobj' in kwargs:			
			self.dataobj = kwargs['dataobj']	# NOTE: validity of data is NOT tested!
			if 'collection' in kwargs:
				self.collection = kwargs['collection']
		
		elif 'leader' in kwargs and 'fields' in kwargs:
			self.dataobj = {'fields':[]}
		
			self.leader = kwargs['leader']			
			self.add_fields(*kwargs['fields'])
			
			# optional lcn
			if 'lcn' in kwargs: self.lcn = kwargs['lcn']
			
			# optional timestamp, create one if not present from current time
			if 'timestamp' in kwargs:
				self.timestamp = kwargs['timestamp']
			else:
				self.timestamp = time_now()
		 
		else:
			raise ValueError("missing arguments in record definition")
		
		# after init, record is always marked as 'not-changed'
		self.changed = False	

		
	@property
	def lcn(self):
		if 'lcn' in self.dataobj:
			return self.dataobj['lcn']
		else:
			return None

	@lcn.setter
	def lcn(self,value):
		if not value and 'lcn' in self.dataobj:	# remove lcn on 'falsey' value
			del self.dataobj['lcn']
		else:
			self.dataobj['lcn'] = str(value)	# lcn is always a string
		
		self.changed = True


	@property
	def timestamp(self):
		return self.dataobj['mod_dt']	# there always be a timestamp in record
		
	@timestamp.setter
	def timestamp(self,value):
		
		if not isinstance(value,datetime):
			raise ValueError('wrong value for record timestamp attribute {}'.format(value))
		
		self.dataobj['mod_dt'] = value
		
		self.changed = True
	
	
	@property
	def leader(self):
		return Leader(dataobj=self.dataobj['leader'],parent=self)
	
	@leader.setter
	def leader(self,value):
		if not isinstance(value,Leader):
			raise ValueError('wrong value for record leader attribute')
		
		if value.parent is not None and value.parent is not self:	
			# leader is attached to another  record
			# make a deep copy of leader dataobj
			copyobj = copy.deepcopy(value.dataobj)
			# set this as the dataobj of leader
			value.dataobj = copyobj
			
		# set leader in dataobj of record
		self.dataobj['leader'] = value.dataobj
		# and make this record the parent of leader
		value.parent = self
		# mark record as changed
		self.changed = True
			
	
	
	
	def set_check_results(self,name,results):
	
		""" sets check results for test `name`. `results` can be
		either a single string or a sequence of strings. Replaces
		any previously existing check results by `name`.
		"""
		
		# force name to text
		name = str(name)
		
		# create set of results
		if isinstance(results,str):
			cro = {'name':name,'result':[results]}
		else:	# treat as sequence, force to strings
			cro = {'name':name,'result':[str(result) for result in results]}
				
		# create check results if they don't exist
		if 'check_results' not in self.dataobj:
			self.dataobj['check_results'] = []
		
		# add result object in check result list, replace any previous
		keylist_add(self.dataobj['check_results'],'name',cro)
		
		# mark record as changed
		self.changed = True
	
	def get_check_results(self,*args):
	
		""" returns a list of (name,result) tuples for check results in record.
		Optionally, check names can be given in `args` to select specific
		results.
		"""
		
		if 'check_results' not in self.dataobj:
			return []
		
		retl = []	
		for checkobj in keylist_get(self.dataobj['check_results'],'name',*args):
			retl.append((checkobj['name'],list(checkobj['result'])))
			
		return retl
		
	
	def remove_check_results(self,*args):
	
		""" removes a check result for check names in `args`. In no names
		are given, all check results are removed. Returns true if any
		results were removed, false otherwise.
		"""
		
		if 'check_results' not in self.dataobj:
			return False
		
		removed = keylist_extract(self.dataobj['check_results'],'name',*args)
		
		# remove completely check_results array from record if no check results left
		if len(self.dataobj['check_results'])==0:
			del self.dataobj['check_results']
		
		if len(removed)>0:
			self.changed = True	# one or more results removed
				
		return self.changed
		
	
	def field_selector_set(self,*args):
	
		""" utility method that returns a set of tag numbers out of
		`args` in the form tagnum (int), 'tagnum' (string), 'tagnum-tagnum'
		(range string) and 'tagnum*' (prefix string). Raises ValueError
		for unaccepted args. The same happens if resulting tag numbers are
		<1 or >999.
		"""
		
		sset = set()
		
		for fspec in args:
			
			if isinstance(fspec,int):
				if fspec<1 or fspec>999:
					raise ValueError('tag number out of limits in field selector')
				
				sset.add(fspec)
						
			elif fspec.endswith(u'*'):	# wildcard X* or XX* fspec
				digits = fspec[:-1]
				dl = len(digits)
				if dl>2 or dl<1: 
					raise ValueError('wrong tag wildcard usage in field selector')
				fillen = 3-dl
				digitsmin = digits+'0'*fillen
				digitsmax = digits+'9'*fillen
				try:
					fmin = int(digitsmin)
					fmax = int(digitsmax)
				except ValueError:
					raise ValueError('non-integer tag wildcard in field selector')
					
				if fmin<1 or fmin>999 or fmax<1 or fmax>999:
					raise ValueError('tag number out of limits in field selector')
				
				sset.update(range(fmin,fmax+1))

			elif fspec.find(u'-')>-1:	# range fspec X-Y
				fl = fspec.split(u'-')
				try:
					fmin = int(fl[0])
					fmax = int(fl[1])
				except ValueError:
					raise ValueError('non-integer tag number in field selector')
					
				if fmin<1 and fmin>999 or fmax<0 or fmax>999 or fmin>fmax:
					raise ValueError('tag number out of limits in field selector')
					
				sset.update(range(fmin,fmax+1))
				
			else:	# must be a sole numerical string
				try:
					fspec = int(fspec)
				except ValueError:
					raise ValueError('non-integer tag number in field selector')
					 
				if fspec<1 or fspec>999:
					raise ValueError('tag number out of limits in field selector')
				
				sset.add(fspec)

		return sset
		
	
	def fields(self,*args):
	
		""" returns a list of fields with tag numbers matching the spec
		provided in `args`. If no args are given, all fields are returned
		"""
		
		# generate set of searched tags
		sset = self.field_selector_set(*args)
		# sorted list of fields in record 
		flist = self.dataobj['fields']
		# get requested fields
		fields = sortlist_get(flist,'tag',*sset)
		# generate field objects
		retl = []
		for fld in fields:
			if fld['tag']<10:
				retl.append(ControlField(dataobj=fld,parent=self))
			else:
				retl.append(DataField(dataobj=fld,parent=self))
		
		return retl


	def add_fields(self,*args):
	
		""" adds a number of field objects (control or data fields)
		contained in `args` to record. If a field has already a parent,
		a deep copy is added instead.
		"""
		
		for field in args:
			if not isinstance(field,Field):
				raise ValueError("cannot add a non Field object to record's fields")
			if field.parent is not None:			
				# field is attached to a record (maybe this record, too)
				# make a deep copy of field's dataobj
				copyobj = copy.deepcopy(field.dataobj)
				# set this as the dataobj of field
				field.dataobj = copyobj
			
			# add field to record's fields
			sortlist_add(self.dataobj['fields'],'tag',int,field.dataobj)
			# set field's parent to this record
			field.parent = self
			# mark record as changed
			self.changed = True
		

	def extract_fields(self,*args):
	
		""" returns a list of fields with tag numbers matching the spec
		provided in `args`. Fields are removed from parent record.
		If no args are given, all fields are returned.
		"""
		
		# generate set of searched tags
		sset = self.field_selector_set(*args)
		# sorted list of fields in record 
		flist = self.dataobj['fields']
		# get requested fields
		fields = sortlist_extract(flist,'tag',*sset)

		# if nothing extracted, return empty list
		if len(fields)==0: return []

		# else, generate field objects with parent set to None
		retl = []
		for fld in fields:
			if fld['tag']<10:
				retl.append(ControlField(dataobj=fld,parent=None))
			else:
				retl.append(DataField(dataobj=fld,parent=None))
		
		# mark record as changed
		self.changed = True
		
		return retl

	
	def detach_field(self,field):
	
		""" removes from fields of record a (previously retrieved) `field`
		object. Field object continues to exist. Does nothing if no `field`
		reference is found. Returns true if a field was detached, false
		otherwise.
		"""
		
		f = sortlist_detach(self.dataobj['fields'],field.dataobj)
		if f:
			field.parent = None
			self.changed = True
			
		return f
	
			
	def update_check_results(self,checker_counter,flush=True,min_log_level=1):
	
		""" utility method that updates record's check results
		with statistics from local counts of `checker_counter`.
		Returns true if record was updated, false otherwise.
		If optional `flush` argument is true, local counts
		are reset after usage.
		An optional `min_log_level` can also be given, to define
		the lowest severity level that will be logged.
		"""
		
		# flag indicating that check results have changed
		changed = False
		
		# get list of checkers
		checkers = checker_counter.checkers()

		# remove any previous results by these checkers
		if self.remove_check_results(*checkers):
			changed = True
		
		# for each checker
		for checker in checkers:
		
			# get result presence (and absence) lists
			present,_ = checker_counter.local_presence(checker)
			
			# rebuilt presence list by adding severity for sorting
			# and by removing results with severity lower than min_log_level
			#(these are not stored)
			sl = []
			for result in present:
				severity = checker_counter.result_severity(checker,result)
				if severity>=min_log_level:
					sl.append((severity,result))
			# sort by increasing severity
			sl.sort()
			
			# set check results for this checker. if anything to set
			if len(sl)>0:
				self.set_check_results(checker,[item[1] for item in sl])
				changed = True
		
		# finally, clear local counts of checker counter if flush is true
		if flush:
			checker_counter.clear_local()
			
		return changed
