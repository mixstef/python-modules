# -*- coding: utf-8 -*-

import copy


from .attach import AttachmentManager

from .subfield import Subfield
from .sortlist import sortlist_get,sortlist_add,sortlist_extract,sortlist_detach

class Field(AttachmentManager):

	""" a field wrapper supperclass """
	
	@property
	def changed(self):
		# no read access to this attribute
		raise AttributeError('cannot read "changed" field attribute')

	@changed.setter
	def changed(self,value):
		if value and self.parent is not None:	# if set to True and there is a parent
			# cascade - set parent's changed attribute
			self.parent.changed = True
		# for any other case, do nothing

	

class ControlField(Field):

	""" A wrapper super class for a marc control field """

	def __init__(self,**kwargs):
	
		""" Initializes a control field instance in various ways,
		according to `kwargs` given, with following priority:
		
		A `dataobj` kwarg is used to fast initialize field
		from a database document, without checking input validity.
		Alternatively, `tag` (a number between 1 and 9) and `data` (a string)
		describe parts of field.
		In case of `dataobj`, an optional `parent` argument can
		be provided, referencing the record that contains this field. 
 
		"""
	
		# the parent record, if any
		self.parent = None
	
		# check if raw data present
		if 'dataobj' in kwargs:
			
			self.dataobj = kwargs['dataobj']	# NOTE: validity of data is NOT tested!

			if 'parent' in kwargs:
				self.parent = kwargs['parent']

		elif 'tag' in kwargs and 'data' in kwargs:
			self.dataobj = {}
			
			# following will be checked for validity in property setters		
			self.tag = kwargs['tag']			
			self.data = kwargs['data']			
					 
		else:
			raise ValueError("missing arguments in control field definition")




	@property
	def tag(self):
		return self.dataobj['tag']

	@tag.setter
	def tag(self,value):
		try:
			value = int(value)
			if value<1 or value>9:
				raise ValueError("invalid tag value for control field")		
			
		except ValueError:
			raise ValueError("invalid tag value for control field")		
		
		# only if case of tag change - NOTE: old value will be missing in construction case
		if 'tag' not in self.dataobj or value != self.dataobj['tag']:

			self.dataobj['tag'] = value
			self.changed = True
			
			# if field is parented, re-arrange tag
			if self.parent is not None:
				parent = self.parent	# keep after detach
				self.parent.detach_field(self)
				parent.add_fields(self)
			


	@property
	def data(self):
		return self.dataobj['data']

	@data.setter
	def data(self,value):
		self.dataobj['data'] = str(value)
		self.changed = True


class DataField(Field):

	""" A wrapper super class for a marc data field """

	def __init__(self,**kwargs):
	
		""" Initializes a data field instance in various ways,
		according to `kwargs` given, with following priority:
		
		A `dataobj` kwarg is used to fast initialize field
		from a database document, without checking input validity.
		Alternatively, `tag` (a number between 10 and 999),
		`ind1` and `ind2` (one ascii char each) and `subfields`
		(a list of Subfield objects) describe parts of field.
		In case of `dataobj`, an optional `parent` argument can
		be provided, referencing the record that contains this field. 
 
		"""
	
		# the parent record, if any
		self.parent = None
	
		# check if raw data present
		if 'dataobj' in kwargs:
			
			self.dataobj = kwargs['dataobj']	# NOTE: validity of data is NOT tested!

			if 'parent' in kwargs:
				self.parent = kwargs['parent']

		elif 'tag' in kwargs and 'ind1' in kwargs and 'ind2' in kwargs and 'subfields' in kwargs:
			self.dataobj = {'subfields':[]}
			
			# following will be checked for validity in property setters		
			self.tag = kwargs['tag']			
			self.ind1 = kwargs['ind1']			
			self.ind2 = kwargs['ind2']
			# add subfields to field			
			self.add_subfields(*kwargs['subfields'])
					 
		else:
			raise ValueError("missing arguments in data field definition")


	@property
	def tag(self):
		return self.dataobj['tag']

	@tag.setter
	def tag(self,value):
		try:
			value = int(value)
			if value<10 or value>999:
				raise ValueError("invalid tag value for data field")		
			
		except ValueError:
			raise ValueError("invalid tag value for data field")		
		
		# only if case of tag change - NOTE: old value will be missing in construction case
		if 'tag' not in self.dataobj or value != self.dataobj['tag']:

			self.dataobj['tag'] = value
			self.changed = True
			
			# if field is parented, re-arrange tag
			if self.parent is not None:
				parent = self.parent	# keep after detach
				self.parent.detach_field(self)
				parent.add_fields(self)


	@property
	def ind1(self):
		return self.dataobj['ind1']

	@ind1.setter
	def ind1(self,value):
		try:
			value = str(value)
			t = value.encode('ascii')
			if len(value)!=1:
				raise ValueError("invalid indicator1 value for data field")
			
		except UnicodeEncodeError:
			raise ValueError("invalid non-ascii indicator1 value for data field")		
		
		self.dataobj['ind1'] = value
		self.changed = True


	@property
	def ind2(self):
		return self.dataobj['ind2']

	@ind2.setter
	def ind2(self,value):
		try:
			value = str(value)
			t = value.encode('ascii')
			if len(value)!=1:
				raise ValueError("invalid indicator2 value for data field")
			
		except UnicodeEncodeError:
			raise ValueError("invalid non-ascii indicator2 value for data field")		
		
		self.dataobj['ind2'] = value
		self.changed = True


	def subfield_selector_set(self,*args):
	
		""" utility method that returns a set of one-letter codes
		out of `args`. The latter are of the form digit (int, 0 to 9),
		'code' (string, '0'-'9' and 'a'-'z'),'scode-ecode' (string,
		start and end codes are either '0'-'9' or 'a'-'z'
		"""
		
		def check_code(code):
			if len(code)!=1: return False
			if (code>='0' and code<='9') or (code>='a' and code<='z'):
				return True
			return False
		
		sset = set()
		
		for sspec in args:
			
			if isinstance(sspec,int): sspec = str(sspec)
			
			if sspec.find('-')>=0:	# range
				sl = sspec.split('-')
				if len(sl)!=2:
					raise ValueError('invalid code range in subfield selector')
				if not check_code(sl[0]):
					raise ValueError('invalid code range start in subfield selector')
				if not check_code(sl[1]):
					raise ValueError('invalid code range end in subfield selector')

				if (sl[0]>='0' and sl[0]<='9') and (sl[1]>='a' and sl[1]<='z'):
					raise ValueError('invalid code range in subfield selector')
				if (sl[0]>='a' and sl[0]<='z') and (sl[1]>='0' and sl[1]<='9'):
					raise ValueError('invalid code range in subfield selector')
					
				if sl[0]>sl[1]:
					sl[0],sl[1] = sl[1],sl[0]
				
				for i in range(ord(sl[0]),ord(sl[1])+1):
					sset.add(chr(i))
				
			else:	# must be single letter/digit code
			
				if not check_code(sspec):
					raise ValueError('invalid code in subfield selector')
					
				sset.add(sspec)
		 		
		return sset


	def subfields(self,*args):
	
		""" returns a list of subfields with codes matching the specs
		provided in `args`. If no args are given, all subfields are returned
		"""
		
		# generate set of searched tags
		sset = self.subfield_selector_set(*args)
		# sorted list of subfields in field 
		flist = self.dataobj['subfields']
		# get requested subfields
		subflist = sortlist_get(flist,'code',*sset)
		# return subfield objects
		return [Subfield(dataobj=sfld,parent=self) for sfld in subflist]


	def extract_subfields(self,*args):
	
		""" returns a list of subfields with codes matching the spec
		provided in `args`. Subfields are removed from parent field.
		If no args are given, all subfields are returned.
		"""
		
		# generate set of searched subfield codes
		sset = self.subfield_selector_set(*args)
		# sorted list of subfields in field 
		sflist = self.dataobj['subfields']
		# get requested subfields
		sfields = sortlist_extract(sflist,'code',*sset)

		# if nothing extracted, return empty list
		if len(sfields)==0: return []

		# mark field as changed
		self.changed = True
		
		# generate subfield objects with parent set to None		
		return [Subfield(dataobj=sfld,parent=None) for sfld in sfields]


	def detach_subfield(self,subfield):
	
		""" removes from subfields of field a (previously retrieved) `subfield`
		object. Subfield object continues to exist. Does nothing if no `subfield`
		reference is found in field. Returns true if a subfield was detached,
		false otherwise.
		"""
		
		f = sortlist_detach(self.dataobj['subfields'],subfield.dataobj)
		if f:
			subfield.parent = None
			self.changed = True
			
		return f
	
			
	def add_subfields(self,*args,sort_key=None):
	
		""" adds a number of subfield objects contained in `args` to record.
		If a field has already a parent, a deep copy is added instead.
		If `sort_key` function is given, it is used to order subfields by code
		by providing compare values for each code. By default, letter codes
		are placed before digit codes. 
		"""
		
		for subfield in args:
			if not isinstance(subfield,Subfield):
				raise ValueError("cannot add a non Subfield object to field's subfields")
				
			if subfield.parent is not None:			
				# subfield is attached to a field (maybe this field!)
				# make a deep copy of subfield's dataobj
				copyobj = copy.deepcopy(subfield.dataobj)
				# set this as the dataobj of subfield
				subfield.dataobj = copyobj
			
			# add subfield to fields's subfields
			if sort_key is None: sort_key = self.default_key_f
			sortlist_add(self.dataobj['subfields'],'code',sort_key,subfield.dataobj)
			# set subfield's parent to this field
			subfield.parent = self
			# mark field as changed
			self.changed = True
	
	
	@staticmethod
	def default_key_f(code):
		if code>='0' and code<='9':
			return ord(code)+1000
		return ord(code)		
