# -*- coding: utf-8 -*-

import operator
from collections import namedtuple


class CheckerInfo:

	""" a simple class to hold information of a checker """
	
	def __init__(self,check_name,check_description,check_results):
	
		""" initializes a checker info object for a checker with `checker_name`,
		`checker_description` and `check_results` (a list of dicts, one
		for each check result, with name,severity and description keys)
		"""
		
		self.check_name = check_name
		self.check_description = check_description
		self.check_results = check_results


class CheckerCounter:

	""" a helper class for calculation of check statistics,
	at record (local) and collection (global) level.
	"""
	
	def __init__(self,*args):
	
		""" initializes a checker counter object based on checker
		info objects provided in `args` (`args` can be non-existing) """
		
			
		# the statistics dict of checker counter
		self.results = {}
		
		for checker in args:
			self.results[checker.check_name] = {'description':checker.check_description,
							    'results':{}}
			rd = self.results[checker.check_name]['results']
			for result in checker.check_results:
				rd[result['name']] = {'severity':result['severity'],
						      'description':result['description'],
						      'local':0,'global':0}
	
	
	def add_checkers(self,*args):
	
		""" adds checker info objects provided in `args`
		to a previously initialized checker counter object """
		
					
		for checker in args:
			self.results[checker.check_name] = {'description':checker.check_description,
							    'results':{}}
			rd = self.results[checker.check_name]['results']
			for result in checker.check_results:
				rd[result['name']] = {'severity':result['severity'],
						      'description':result['description'],
						      'local':0,'global':0}
	
	
	def count(self,check_name,check_result):
	
		""" increments local and global counts of checker `check_name`
		and result `check_result'
		"""
		
		if check_name not in self.results:
			raise ValueError('checker name not found')
		
		rd = self.results[check_name]['results']
		
		if check_result not in rd:
			raise ValueError('checker result not found')
		
		rd[check_result]['local'] += 1
		rd[check_result]['global'] += 1


	def count_once(self,check_name,check_result):
	
		""" increments local and global counts of checker `check_name`
		and result `check_result', onlt if local counter equals 0.
		To be used for counting incidents only once per record.
		"""
		
		if check_name not in self.results:
			raise ValueError('checker name not found')
		
		rd = self.results[check_name]['results']
		
		if check_result not in rd:
			raise ValueError('checker result not found')
		
		if rd[check_result]['local']==0: 
			rd[check_result]['local'] = 1
			rd[check_result]['global'] += 1


	def clear(self):
	
		""" clears local and global counts for all checkers and all results """

		for _,checker_info in self.results.items():
			for _,result_info in checker_info['results'].items():
				result_info['local'] = 0
				result_info['global'] = 0


	def clear_local(self):
	
		""" clears local only counts for all checkers and all results """

		for _,checker_info in self.results.items():
			for _,result_info in checker_info['results'].items():
				result_info['local'] = 0


	def local_results(self,checker):
	
		""" returns a list of result info for `checker`. Each value is a
		named tuple of (name,severity,description,count) with counts drawn 
		from local counters.
		"""
		
		return self._results(checker,operator.itemgetter('local'))
		

	def global_results(self,checker):
	
		""" returns a list of result info for `checker`. Each value is a
		named tuple of (name,severity,description,count) with counts drawn 
		from global counters.
		"""
		
		return self._results(checker,operator.itemgetter('global'))
		
	
	def _results(self,checker,selector):
	
		""" returns a list of result info for `checker`. Each value is a
		named tuple of (name,severity,description,count) with counts drawn
		from counters selected by `selector` itemgetter.
		"""	

		if checker not in self.results:
			raise ValueError('checker name not found')
		
		rd =  self.results[checker]['results']

		retl = []
		Results = namedtuple('Results',['name','severity','description','count'])
		for result,result_info in rd.items():
			count = selector(result_info)
			retl.append(Results(name=result,severity=result_info['severity'],
					    description=result_info['description'],count=count))
		
		return retl
		
		
		
	def checker_description(self,checker):
	
		""" utility method that returns the description string of `checker` """
		
		if checker not in self.results:
			raise ValueError('checker name not found')

		return self.results[checker]['description']
		
		
	def result_description(self,checker,result):
	
		""" utility method that returns the description string of `checker`, `result` """
		
		if checker not in self.results:
			raise ValueError('checker name not found')

		rd =  self.results[checker]['results']
		
		if result not in rd:
			raise ValueError('checker result not found')

		return rd[result]['description']


	def result_severity(self,checker,result):
	
		""" utility method that returns the severity of `checker`, `result` """
		
		if checker not in self.results:
			raise ValueError('checker name not found')

		rd =  self.results[checker]['results']
		
		if result not in rd:
			raise ValueError('checker result not found')

		return rd[result]['severity']


	def checkers(self):
	
		""" returns a list of checkers in this counter """
		
		return self.results
		
	
	def local_presence(self,checker):
	
		""" returns two lists of present (count>0) and absent result names
		for `checker` with counts drawn from local counts
		"""
		
		return self._presence(checker,operator.itemgetter('local'))

		
	def global_presence(self,checker):
	
		""" returns two lists of present (count>0) and absent result names
		for `checker` with counts drawn from global counts
		"""
		
		return self._presence(checker,operator.itemgetter('global'))
		

	def _presence(self,checker,selector):
	
		""" returns two lists of present (count>0) and absent result names
		for `checker` with counts drawn from local or global counts by `selector`
		"""

		
		if checker not in self.results:
			raise ValueError('checker name not found')
		
		rd =  self.results[checker]['results']

		present,absent = [],[]
		for result,result_info in rd.items():
			count = selector(result_info)
			if count>0: present.append(result)
			else: absent.append(result)
			
		return present,absent
				
